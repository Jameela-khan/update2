<?php
$hostname = "http://localhost/phpproject";

$conn = mysqli_connect("localhost","root","","blogging") or die("Connection failed : " . mysqli_connect_error());

?>